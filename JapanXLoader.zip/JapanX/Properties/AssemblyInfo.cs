﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("2.0.372.0")]
[assembly: AssemblyTitle("JapanX Mod 2.0 (Preview)")]
[assembly: AssemblyDescription("JapanX Mod 2.0 (Preview) For CarX")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Zi9 - JapanX")]
[assembly: AssemblyProduct("JapanX Mod 2.0 (Preview)")]
[assembly: AssemblyCopyright("Copyright © Zi9 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("84c045d9-9909-4112-baae-1cb2106b30eb")]
